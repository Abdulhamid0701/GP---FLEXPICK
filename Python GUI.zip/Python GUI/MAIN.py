import gui_custom_gp
import serial 
from gui_custom_gp import byte_sent
from gui_custom_gp import send_byte
from gui_custom_gp import app

#ser = serial.Serial('com7', 9600)
app.mainloop()
